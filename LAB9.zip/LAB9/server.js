const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

const db = new sqlite3.Database('./banco_de_dados.sqlite');

db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS posts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        titulo TEXT,
        resumo TEXT,
        conteudo TEXT
    )`);
});

function inserirPost(titulo, resumo, conteudo, callback) {
    const sql = `INSERT INTO posts (titulo, resumo, conteudo) VALUES (?, ?, ?)`;
    db.run(sql, [titulo, resumo, conteudo], callback);
}

function buscarPosts(callback) {
    const sql = `SELECT * FROM posts ORDER BY id DESC`;
    db.all(sql, [], callback);
}

app.get('/', (req, res) => {
    res.send(`
        <div style="text-align:center; font-family: Arial; margin-top: 50px;">
            <h1>Bem-vindo à Página de Projetos</h1>
            <p>Esta é a página principal.</p>
            <a href="/cadastrar_post.html">Cadastrar um Post</a> | 
            <a href="/blog">Acessar o Blog</a>
        </div>
    `);
});

app.get('/blog', (req, res) => {
    buscarPosts((err, rows) => {
        if (err) {
            console.error(err);
            return res.status(500).send("Erro ao buscar no banco de dados.");
        }
        res.render('blog', { posts: rows });
    });
});

app.post('/cadastrar', (req, res) => {
    const { titulo, resumo, conteudo } = req.body;
    
    inserirPost(titulo, resumo, conteudo, function(err) {
        if (err) {
            console.error(err);
            return res.status(500).send("Erro ao salvar o post.");
        }
        res.redirect('/blog');
    });
});

app.listen(80, () => {
    console.log("Servidor rodando! Acesse http://localhost no seu navegador.");
});